package com.ufv.userAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tests_Prestamos {

	@Test
	void Prueba_Prestamo_1() {
	}

}
